package com.example.club.repository;

import com.example.club.entity.Asociacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AsociacionRepository extends JpaRepository<Asociacion, Long> {
}
